"""
Database utilities for storing betting data and predictions using PostgreSQL
"""

import os
from sqlalchemy.orm import sessionmaker
from sqlalchemy import func
from models import Base, BettingData, Prediction, UserInteraction, engine, get_db_session, create_tables
from utils.logger import get_logger
import json

logger = get_logger("Database")

class Database:
    def __init__(self):
        create_tables()
        logger.info("Database initialized successfully")
    
    def insert_betting_data(self, sport, market, team1, team2, odds, volume=0, metadata=None):
        """Insert betting data into database"""
        db = get_db_session()
        try:
            betting_entry = BettingData(
                sport=sport,
                market=market,
                team1=team1,
                team2=team2,
                odds=odds,
                volume=volume,
                meta_data=metadata
            )
            db.add(betting_entry)
            db.commit()
        except Exception as e:
            db.rollback()
            logger.error(f"Error inserting betting data: {e}")
        finally:
            db.close()
    
    def get_betting_data(self, sport=None, market=None, limit=1000):
        """Retrieve betting data from database"""
        db = get_db_session()
        try:
            query = db.query(BettingData)
            
            if sport:
                query = query.filter(BettingData.sport == sport)
            if market:
                query = query.filter(BettingData.market == market)
            
            results = query.order_by(BettingData.timestamp.desc()).limit(limit).all()
            
            # Convert to list of dictionaries
            return [{
                'id': row.id,
                'sport': row.sport,
                'market': row.market,
                'team1': row.team1,
                'team2': row.team2,
                'odds': row.odds,
                'volume': row.volume,
                'metadata': row.meta_data,
                'timestamp': row.timestamp.isoformat() if row.timestamp is not None else None
            } for row in results]
        except Exception as e:
            logger.error(f"Error retrieving betting data: {e}")
            return []
        finally:
            db.close()
    
    def insert_prediction(self, sport, market, match_info, prediction, confidence):
        """Insert prediction into database"""
        db = get_db_session()
        try:
            prediction_entry = Prediction(
                sport=sport,
                market=market,
                match_info=match_info,
                prediction=prediction,
                confidence=confidence
            )
            db.add(prediction_entry)
            db.commit()
        except Exception as e:
            db.rollback()
            logger.error(f"Error inserting prediction: {e}")
        finally:
            db.close()
    
    def get_predictions(self, sport=None, limit=100):
        """Retrieve predictions from database"""
        db = get_db_session()
        try:
            query = db.query(Prediction)
            
            if sport:
                query = query.filter(Prediction.sport == sport)
            
            results = query.order_by(Prediction.timestamp.desc()).limit(limit).all()
            
            # Convert to list of dictionaries
            return [{
                'id': row.id,
                'sport': row.sport,
                'market': row.market,
                'match_info': row.match_info,
                'prediction': row.prediction,
                'confidence': row.confidence,
                'timestamp': row.timestamp.isoformat() if row.timestamp is not None else None
            } for row in results]
        except Exception as e:
            logger.error(f"Error retrieving predictions: {e}")
            return []
        finally:
            db.close()
    
    def log_user_interaction(self, user_id, command, response):
        """Log user interaction"""
        db = get_db_session()
        try:
            interaction = UserInteraction(
                user_id=str(user_id),
                command=command,
                response=response
            )
            db.add(interaction)
            db.commit()
        except Exception as e:
            db.rollback()
            logger.error(f"Error logging user interaction: {e}")
        finally:
            db.close()
    
    def get_statistics(self):
        """Get general statistics about the data"""
        db = get_db_session()
        try:
            # Count betting data entries
            betting_count = db.query(func.count(BettingData.id)).scalar()
            
            # Count predictions
            predictions_count = db.query(func.count(Prediction.id)).scalar()
            
            # Count user interactions
            interactions_count = db.query(func.count(UserInteraction.id)).scalar()
            
            # Get unique sports
            sports = db.query(BettingData.sport).distinct().all()
            sports_list = [sport[0] for sport in sports]
            
            # Get recent betting data count
            recent_data_count = db.query(func.count(BettingData.id)).limit(10).scalar()
            
            return {
                'betting_data_count': betting_count or 0,
                'predictions_count': predictions_count or 0,
                'interactions_count': interactions_count or 0,
                'sports_covered': sports_list,
                'recent_entries': recent_data_count or 0
            }
        except Exception as e:
            logger.error(f"Error getting statistics: {e}")
            return {
                'betting_data_count': 0,
                'predictions_count': 0,
                'interactions_count': 0,
                'sports_covered': [],
                'recent_entries': 0
            }
        finally:
            db.close()
