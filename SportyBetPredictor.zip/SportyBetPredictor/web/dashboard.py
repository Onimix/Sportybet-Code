"""
Web dashboard for displaying betting data and analytics
"""

from flask import Flask, render_template, jsonify
import json
import pandas as pd
from datetime import datetime, timedelta
from utils.database import Database
from analysis.analyzer import BettingAnalyzer
from analysis.predictor import BettingPredictor
from utils.logger import get_logger
from config import DASHBOARD_HOST, DASHBOARD_PORT

logger = get_logger("Dashboard")

class DashboardServer:
    def __init__(self):
        self.app = Flask(__name__, template_folder='../templates', static_folder='../static')
        self.db = Database()
        self.analyzer = BettingAnalyzer()
        self.predictor = BettingPredictor()
        self.setup_routes()
    
    def setup_routes(self):
        """Setup Flask routes"""
        
        @self.app.route('/')
        def dashboard():
            """Main dashboard page"""
            return render_template('dashboard.html')
        
        @self.app.route('/api/stats')
        def api_stats():
            """API endpoint for general statistics"""
            try:
                stats = self.db.get_statistics()
                return jsonify(stats)
            except Exception as e:
                logger.error(f"Error getting stats: {e}")
                return jsonify({"error": str(e)}), 500
        
        @self.app.route('/api/trends')
        def api_trends():
            """API endpoint for trends analysis"""
            try:
                trends = self.analyzer.analyze_odds_trends()
                return jsonify(trends)
            except Exception as e:
                logger.error(f"Error getting trends: {e}")
                return jsonify({"error": str(e)}), 500
        
        @self.app.route('/api/recent-data')
        def api_recent_data():
            """API endpoint for recent betting data"""
            try:
                data = self.db.get_betting_data(limit=100)
                return jsonify(data)
            except Exception as e:
                logger.error(f"Error getting recent data: {e}")
                return jsonify({"error": str(e)}), 500
        
        @self.app.route('/api/predictions')
        def api_predictions():
            """API endpoint for recent predictions"""
            try:
                predictions = self.db.get_predictions(limit=50)
                return jsonify(predictions)
            except Exception as e:
                logger.error(f"Error getting predictions: {e}")
                return jsonify({"error": str(e)}), 500
        
        @self.app.route('/api/daily-summary')
        def api_daily_summary():
            """API endpoint for daily predictions summary"""
            try:
                summary = self.predictor.get_daily_predictions()
                return jsonify(summary)
            except Exception as e:
                logger.error(f"Error getting daily summary: {e}")
                return jsonify({"error": str(e)}), 500
        
        @self.app.route('/api/value-bets')
        def api_value_bets():
            """API endpoint for value betting opportunities"""
            try:
                value_bets = self.analyzer.find_value_bets()
                return jsonify(value_bets)
            except Exception as e:
                logger.error(f"Error getting value bets: {e}")
                return jsonify({"error": str(e)}), 500
        
        @self.app.route('/api/chart-data')
        def api_chart_data():
            """API endpoint for chart data"""
            try:
                data = self.db.get_betting_data(limit=200)
                
                if not data:
                    return jsonify({"error": "No data available"})
                
                # Convert data to pandas for analysis
                df = pd.DataFrame(data)
                
                # Prepare data for charts
                df['timestamp'] = pd.to_datetime(df['timestamp'])
                df['date'] = df['timestamp'].dt.date
                
                # Daily odds trends
                daily_odds = df.groupby('date')['odds'].mean().reset_index()
                daily_odds['date'] = daily_odds['date'].astype(str)
                
                # Sport distribution
                sport_dist = df['sport'].value_counts().to_dict()
                
                # Market distribution
                market_dist = df['market'].value_counts().to_dict()
                
                chart_data = {
                    "daily_odds": daily_odds.to_dict('records'),
                    "sport_distribution": sport_dist,
                    "market_distribution": market_dist
                }
                
                return jsonify(chart_data)
                
            except Exception as e:
                logger.error(f"Error getting chart data: {e}")
                return jsonify({"error": str(e)}), 500
    
    def run(self):
        """Run the Flask dashboard server"""
        try:
            logger.info(f"Starting dashboard server on {DASHBOARD_HOST}:{DASHBOARD_PORT}")
            self.app.run(
                host=DASHBOARD_HOST,
                port=DASHBOARD_PORT,
                debug=False,
                use_reloader=False
            )
        except Exception as e:
            logger.error(f"Error running dashboard server: {e}")
