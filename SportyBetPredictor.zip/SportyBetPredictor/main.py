#!/usr/bin/env python3
"""
Main entry point for the Sports Betting Prediction Telegram Bot
"""

import asyncio
import logging
import threading
from bot.telegram_bot import SportsBettingBot
from data.data_collector import DataCollector
from web.dashboard import DashboardServer
from utils.logger import setup_logger

def main():
    """Main function to start all services"""
    # Setup logging
    logger = setup_logger()
    logger.info("Starting Sports Betting Prediction Bot...")
    
    try:
        # Initialize components
        data_collector = DataCollector()
        bot = SportsBettingBot()
        dashboard = DashboardServer()
        
        # Start data collection in background thread
        data_thread = threading.Thread(target=data_collector.start_collection, daemon=True)
        data_thread.start()
        logger.info("Data collection started")
        
        # Start web dashboard in background thread
        dashboard_thread = threading.Thread(target=dashboard.run, daemon=True)
        dashboard_thread.start()
        logger.info("Web dashboard started on http://0.0.0.0:5000")
        
        # Start telegram bot (blocking)
        logger.info("Starting Telegram bot...")
        bot.run()
        
    except KeyboardInterrupt:
        logger.info("Shutting down...")
    except Exception as e:
        logger.error(f"Error starting application: {e}")
        raise

if __name__ == "__main__":
    main()
