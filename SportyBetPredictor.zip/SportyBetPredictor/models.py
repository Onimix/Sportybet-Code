"""
Database models for the Sports Betting Bot using SQLAlchemy
"""
import os
from datetime import datetime
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, Text, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

Base = declarative_base()

class BettingData(Base):
    __tablename__ = 'betting_data'
    
    id = Column(Integer, primary_key=True)
    sport = Column(String(50), nullable=False)
    market = Column(String(100), nullable=False)
    team1 = Column(String(100), nullable=False)
    team2 = Column(String(100))
    odds = Column(Float, nullable=False)
    volume = Column(Float, default=0)
    meta_data = Column(JSON)
    timestamp = Column(DateTime, default=datetime.utcnow)

class Prediction(Base):
    __tablename__ = 'predictions'
    
    id = Column(Integer, primary_key=True)
    sport = Column(String(50), nullable=False)
    market = Column(String(100), nullable=False)
    match_info = Column(String(200), nullable=False)
    prediction = Column(String(100), nullable=False)
    confidence = Column(Float, nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)

class UserInteraction(Base):
    __tablename__ = 'user_interactions'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(String(50), nullable=False)
    command = Column(String(100), nullable=False)
    response = Column(Text)
    timestamp = Column(DateTime, default=datetime.utcnow)

# Database setup
DATABASE_URL = os.environ.get('DATABASE_URL', 'postgresql://localhost:5432/sports_betting')
engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def create_tables():
    """Create all tables"""
    Base.metadata.create_all(bind=engine)

def get_db_session():
    """Get database session"""
    db = SessionLocal()
    try:
        return db
    finally:
        pass  # Session will be closed by caller