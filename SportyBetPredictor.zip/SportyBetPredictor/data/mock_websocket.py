"""
Mock WebSocket client to simulate sports betting data streams
"""

import asyncio
import json
import random
import time
from datetime import datetime, timedelta
from utils.logger import get_logger
from config import MOCK_TEAMS, BETTING_MARKETS, SUPPORTED_SPORTS

logger = get_logger("MockWebSocket")

class MockWebSocketClient:
    def __init__(self):
        self.is_running = False
        self.callbacks = []
    
    def add_callback(self, callback):
        """Add callback function to handle incoming data"""
        self.callbacks.append(callback)
    
    def generate_betting_data(self):
        """Generate realistic mock betting data"""
        sport = random.choice(SUPPORTED_SPORTS)
        market = random.choice(BETTING_MARKETS)
        
        # Generate team data based on sport
        if sport in MOCK_TEAMS:
            teams = random.sample(MOCK_TEAMS[sport], 2)
            team1, team2 = teams[0], teams[1]
        else:
            team1 = f"Team A"
            team2 = f"Team B"
        
        # Generate realistic odds based on market type
        if market == "match_winner":
            # Odds for match winner (e.g., 1.85 vs 2.10)
            odds = round(random.uniform(1.10, 4.50), 2)
        elif market == "over_under":
            # Over/Under odds (usually close to even)
            odds = round(random.uniform(1.75, 2.25), 2)
        elif market == "handicap":
            # Handicap odds
            odds = round(random.uniform(1.60, 2.40), 2)
        elif market == "both_teams_score":
            # Yes/No odds
            odds = round(random.uniform(1.50, 2.80), 2)
        else:
            # Default odds
            odds = round(random.uniform(1.20, 5.00), 2)
        
        # Generate volume (betting activity)
        volume = random.randint(10, 1000)
        
        # Additional metadata
        metadata = {
            "league": f"{sport.title()} League",
            "match_time": (datetime.now() + timedelta(hours=random.randint(1, 72))).isoformat(),
            "market_type": market,
            "bookmaker": "SportyBet Virtual"
        }
        
        data = {
            "timestamp": datetime.now().isoformat(),
            "sport": sport,
            "market": market,
            "team1": team1,
            "team2": team2,
            "odds": odds,
            "volume": volume,
            "metadata": metadata
        }
        
        return data
    
    async def start_streaming(self):
        """Start streaming mock data"""
        self.is_running = True
        logger.info("Mock WebSocket streaming started")
        
        while self.is_running:
            try:
                # Generate new betting data
                data = self.generate_betting_data()
                
                # Call all registered callbacks
                for callback in self.callbacks:
                    try:
                        if asyncio.iscoroutinefunction(callback):
                            await callback(data)
                        else:
                            callback(data)
                    except Exception as e:
                        logger.error(f"Error in callback: {e}")
                
                # Wait before generating next data point
                await asyncio.sleep(random.uniform(2, 8))
                
            except Exception as e:
                logger.error(f"Error in mock websocket streaming: {e}")
                await asyncio.sleep(5)
    
    def stop_streaming(self):
        """Stop streaming mock data"""
        self.is_running = False
        logger.info("Mock WebSocket streaming stopped")

# Alternative synchronous version for threading
class MockWebSocketSync:
    def __init__(self):
        self.is_running = False
        self.callbacks = []
        self.client = MockWebSocketClient()
    
    def add_callback(self, callback):
        """Add callback function to handle incoming data"""
        self.callbacks.append(callback)
    
    def start_streaming(self):
        """Start streaming mock data (synchronous)"""
        self.is_running = True
        logger.info("Mock WebSocket sync streaming started")
        
        while self.is_running:
            try:
                # Generate new betting data
                data = self.client.generate_betting_data()
                
                # Call all registered callbacks
                for callback in self.callbacks:
                    try:
                        callback(data)
                    except Exception as e:
                        logger.error(f"Error in sync callback: {e}")
                
                # Wait before generating next data point
                time.sleep(random.uniform(3, 10))
                
            except Exception as e:
                logger.error(f"Error in mock websocket sync streaming: {e}")
                time.sleep(5)
    
    def stop_streaming(self):
        """Stop streaming mock data"""
        self.is_running = False
        logger.info("Mock WebSocket sync streaming stopped")
