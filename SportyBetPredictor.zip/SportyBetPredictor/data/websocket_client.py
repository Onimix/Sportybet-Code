"""
Real WebSocket client for SportyBet data collection
"""

import json
import threading
import time
import websocket
from utils.logger import get_logger
from config import WEBSOCKET_URL

logger = get_logger("SportyBetWebSocket")

class SportyBetWebSocketClient:
    def __init__(self):
        self.ws = None
        self.is_running = False
        self.callbacks = []
        self.reconnect_delay = 5
        self.max_reconnect_attempts = 10
        self.reconnect_attempts = 0
    
    def add_callback(self, callback):
        """Add callback function to handle incoming data"""
        self.callbacks.append(callback)
    
    def on_message(self, ws, message):
        """Handle WebSocket messages"""
        try:
            # SportyBet uses Socket.IO protocol
            # Messages come prefixed with numeric codes like "42["event", {...}]"
            if message.startswith("42"):
                # Remove the '42' prefix and parse JSON array
                payload = message[2:]
                data = json.loads(payload)
                event = data[0]
                content = data[1] if len(data) > 1 else {}
                
                # Process virtual football result events
                if event in ["vFootballResult", "virtualFootballResult", "gameResult"]:
                    processed_data = self.process_virtual_football_data(content)
                    if processed_data:
                        for callback in self.callbacks:
                            try:
                                callback(processed_data)
                            except Exception as e:
                                logger.error(f"Error in callback: {e}")
                
                logger.debug(f"Received event: {event}")
                        
        except Exception as e:
            logger.error(f"Error parsing message: {e}")
    
    def process_virtual_football_data(self, content):
        """Process virtual football data into standard format"""
        try:
            # Extract relevant information from SportyBet virtual football data
            # This will vary based on the actual data structure
            
            processed_data = {
                "timestamp": time.time(),
                "sport": "virtual_football",
                "market": "match_winner",
                "team1": content.get("home_team", "Team A"),
                "team2": content.get("away_team", "Team B"),
                "odds": content.get("home_odds", 2.0),
                "volume": content.get("volume", 100),
                "metadata": {
                    "league": content.get("league", "Virtual League"),
                    "match_id": content.get("match_id", "unknown"),
                    "score": content.get("score", "0-0"),
                    "match_time": content.get("match_time", ""),
                    "bookmaker": "SportyBet Virtual"
                }
            }
            
            return processed_data
            
        except Exception as e:
            logger.error(f"Error processing virtual football data: {e}")
            return None
    
    def on_error(self, ws, error):
        """Handle WebSocket errors"""
        logger.error(f"WebSocket error: {error}")
    
    def on_close(self, ws, close_status_code, close_msg):
        """Handle WebSocket close"""
        logger.info(f"WebSocket connection closed: {close_status_code} - {close_msg}")
        
        # Attempt to reconnect if still running
        if self.is_running and self.reconnect_attempts < self.max_reconnect_attempts:
            self.reconnect_attempts += 1
            logger.info(f"Attempting to reconnect ({self.reconnect_attempts}/{self.max_reconnect_attempts})...")
            time.sleep(self.reconnect_delay)
            self.connect()
    
    def on_open(self, ws):
        """Handle WebSocket open"""
        logger.info("Connected to SportyBet WebSocket")
        self.reconnect_attempts = 0
        
        # Send any required initialization messages for Socket.IO
        # This might be needed for SportyBet's specific implementation
        try:
            # Socket.IO handshake
            ws.send("40")  # Socket.IO connect message
        except Exception as e:
            logger.error(f"Error sending handshake: {e}")
    
    def connect(self):
        """Connect to SportyBet WebSocket"""
        try:
            self.ws = websocket.WebSocketApp(
                WEBSOCKET_URL,
                on_open=self.on_open,
                on_message=self.on_message,
                on_error=self.on_error,
                on_close=self.on_close
            )
            
            # Run WebSocket connection
            self.ws.run_forever()
            
        except Exception as e:
            logger.error(f"Error connecting to SportyBet WebSocket: {e}")
    
    def start_streaming(self):
        """Start WebSocket streaming"""
        self.is_running = True
        logger.info("Starting SportyBet WebSocket streaming...")
        
        # Run connection in current thread (blocking)
        self.connect()
    
    def stop_streaming(self):
        """Stop WebSocket streaming"""
        self.is_running = False
        if self.ws:
            self.ws.close()
        logger.info("SportyBet WebSocket streaming stopped")