"""
Data collection service that gathers and stores betting data
"""

import threading
import time
from utils.database import Database
from utils.logger import get_logger
from data.websocket_client import SportyBetWebSocketClient
from data.mock_websocket import MockWebSocketSync

logger = get_logger("DataCollector")

class DataCollector:
    def __init__(self, use_real_websocket=True):
        self.db = Database()
        self.use_real_websocket = use_real_websocket
        
        if use_real_websocket:
            self.websocket_client = SportyBetWebSocketClient()
        else:
            self.websocket_client = MockWebSocketSync()
            
        self.is_collecting = False
        
        # Register callback for incoming data
        self.websocket_client.add_callback(self.handle_betting_data)
    
    def handle_betting_data(self, data):
        """Handle incoming betting data and store it"""
        try:
            logger.debug(f"Received betting data: {data['sport']} - {data['team1']} vs {data['team2']}")
            
            # Store data in database
            self.db.insert_betting_data(
                sport=data['sport'],
                market=data['market'],
                team1=data['team1'],
                team2=data['team2'],
                odds=data['odds'],
                volume=data['volume'],
                metadata=data['metadata']
            )
            
            logger.info(f"Stored betting data: {data['sport']} {data['market']} - Odds: {data['odds']}")
            
        except Exception as e:
            logger.error(f"Error handling betting data: {e}")
    
    def start_collection(self):
        """Start data collection process"""
        try:
            logger.info("Starting data collection...")
            self.is_collecting = True
            
            # Start websocket streaming (this will block)
            self.websocket_client.start_streaming()
            
        except Exception as e:
            logger.error(f"Error in data collection: {e}")
            self.is_collecting = False
    
    def stop_collection(self):
        """Stop data collection process"""
        logger.info("Stopping data collection...")
        self.is_collecting = False
        self.websocket_client.stop_streaming()
    
    def get_latest_data(self, sport=None, limit=50):
        """Get latest collected data"""
        return self.db.get_betting_data(sport=sport, limit=limit)
    
    def get_collection_stats(self):
        """Get statistics about data collection"""
        return self.db.get_statistics()
