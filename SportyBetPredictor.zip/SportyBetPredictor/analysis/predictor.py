"""
Prediction algorithms for sports betting based on collected data
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
from utils.database import Database
from utils.logger import get_logger
from config import MIN_DATA_POINTS, PREDICTION_CONFIDENCE_THRESHOLD

logger = get_logger("Predictor")

class BettingPredictor:
    def __init__(self):
        self.db = Database()
        self.scaler = StandardScaler()
    
    def prepare_features(self, data):
        """Prepare features for prediction model"""
        try:
            features = []
            
            for _, row in data.iterrows():
                feature_row = [
                    row['odds'],
                    row['volume'],
                    hash(row['sport']) % 1000,  # Sport encoding
                    hash(row['market']) % 1000,  # Market encoding
                    hash(row['team1']) % 1000,   # Team1 encoding
                ]
                
                # Add time-based features
                timestamp = pd.to_datetime(row['timestamp'])
                feature_row.extend([
                    timestamp.hour,
                    timestamp.day_of_week,
                    timestamp.day
                ])
                
                features.append(feature_row)
            
            return np.array(features)
            
        except Exception as e:
            logger.error(f"Error preparing features: {e}")
            return np.array([])
    
    def predict_match_outcome(self, sport, team1, team2, market="match_winner"):
        """Predict match outcome based on historical data"""
        try:
            # Get relevant historical data
            data = self.db.get_betting_data(sport=sport, limit=200)
            
            if not data or len(data) < MIN_DATA_POINTS:
                return {
                    "error": f"Insufficient data for prediction. Need at least {MIN_DATA_POINTS} data points.",
                    "available_data": len(data) if data else 0
                }
            
            # Convert to DataFrame for analysis
            df = pd.DataFrame(data)
            
            # Filter data for similar matches
            similar_data = df[
                (df['sport'] == sport) & 
                (df['market'] == market) &
                ((df['team1'].str.contains(team1, case=False, na=False)) |
                 (df['team2'].str.contains(team1, case=False, na=False)) |
                 (df['team1'].str.contains(team2, case=False, na=False)) |
                 (df['team2'].str.contains(team2, case=False, na=False)))
            ]
            
            # Team-specific analysis
            team1_data = df[
                (df['team1'].str.contains(team1, case=False, na=False)) |
                (df['team2'].str.contains(team1, case=False, na=False))
            ]
            
            team2_data = df[
                (df['team1'].str.contains(team2, case=False, na=False)) |
                (df['team2'].str.contains(team2, case=False, na=False))
            ]
            
            # Calculate prediction metrics
            prediction = {
                "match": f"{team1} vs {team2}",
                "sport": sport,
                "market": market,
                "timestamp": datetime.now().isoformat()
            }
            
            # Odds-based prediction
            if not similar_data.empty:
                avg_odds = similar_data['odds'].mean()
                odds_std = similar_data['odds'].std()
                prediction["expected_odds"] = round(avg_odds, 2)
                prediction["odds_volatility"] = round(odds_std, 2)
            else:
                # Use sport-wide averages
                sport_data = data[data['sport'] == sport]
                if not sport_data.empty:
                    prediction["expected_odds"] = round(sport_data['odds'].mean(), 2)
                    prediction["odds_volatility"] = round(sport_data['odds'].std(), 2)
                else:
                    prediction["expected_odds"] = 2.0
                    prediction["odds_volatility"] = 0.5
            
            # Team strength analysis
            if not team1_data.empty:
                team1_avg_odds = team1_data['odds'].mean()
                team1_matches = len(team1_data)
            else:
                team1_avg_odds = 2.0
                team1_matches = 0
            
            if not team2_data.empty:
                team2_avg_odds = team2_data['odds'].mean()
                team2_matches = len(team2_data)
            else:
                team2_avg_odds = 2.0
                team2_matches = 0
            
            # Simple prediction logic
            if team1_avg_odds < team2_avg_odds:
                predicted_winner = team1
                confidence = min(0.95, 0.5 + abs(team2_avg_odds - team1_avg_odds) / 4)
            elif team2_avg_odds < team1_avg_odds:
                predicted_winner = team2
                confidence = min(0.95, 0.5 + abs(team1_avg_odds - team2_avg_odds) / 4)
            else:
                predicted_winner = "Draw/Even"
                confidence = 0.5
            
            # Adjust confidence based on data availability
            data_factor = min(1.0, len(similar_data) / 20)
            confidence = confidence * data_factor + 0.3 * (1 - data_factor)
            
            prediction.update({
                "predicted_winner": predicted_winner,
                "confidence": round(confidence, 2),
                "team1_avg_odds": round(team1_avg_odds, 2),
                "team2_avg_odds": round(team2_avg_odds, 2),
                "team1_matches_analyzed": team1_matches,
                "team2_matches_analyzed": team2_matches,
                "similar_matches_found": len(similar_data),
                "total_data_points": len(data)
            })
            
            # Add recommendation
            if confidence >= PREDICTION_CONFIDENCE_THRESHOLD:
                prediction["recommendation"] = f"Strong prediction: {predicted_winner}"
            elif confidence >= 0.5:
                prediction["recommendation"] = f"Moderate prediction: {predicted_winner}"
            else:
                prediction["recommendation"] = "Low confidence - avoid betting"
            
            # Store prediction in database
            self.db.insert_prediction(
                sport=sport,
                market=market,
                match_info=f"{team1} vs {team2}",
                prediction=predicted_winner,
                confidence=confidence
            )
            
            logger.info(f"Generated prediction for {team1} vs {team2}: {predicted_winner} ({confidence:.2f})")
            return prediction
            
        except Exception as e:
            logger.error(f"Error predicting match outcome: {e}")
            return {"error": str(e)}
    
    def predict_odds_movement(self, sport, market, team1, team2=None):
        """Predict odds movement direction"""
        try:
            # Get recent data for similar matches
            data = self.db.get_betting_data(sport=sport, limit=100)
            
            if data.empty or len(data) < 10:
                return {"error": "Insufficient data for odds movement prediction"}
            
            # Filter relevant data
            relevant_data = data[
                (data['sport'] == sport) & 
                (data['market'] == market)
            ]
            
            if relevant_data.empty:
                return {"error": f"No data found for {sport} {market}"}
            
            # Analyze recent trends
            recent_data = relevant_data.head(20)
            older_data = relevant_data.tail(20)
            
            recent_avg = recent_data['odds'].mean()
            older_avg = older_data['odds'].mean()
            
            # Predict direction
            if recent_avg > older_avg:
                direction = "increasing"
                confidence = min(0.9, abs(recent_avg - older_avg) / older_avg)
            elif recent_avg < older_avg:
                direction = "decreasing"
                confidence = min(0.9, abs(older_avg - recent_avg) / older_avg)
            else:
                direction = "stable"
                confidence = 0.7
            
            prediction = {
                "sport": sport,
                "market": market,
                "match": f"{team1} vs {team2}" if team2 else team1,
                "direction": direction,
                "confidence": round(confidence, 2),
                "recent_avg_odds": round(recent_avg, 2),
                "historical_avg_odds": round(older_avg, 2),
                "data_points_analyzed": len(relevant_data),
                "timestamp": datetime.now().isoformat()
            }
            
            logger.info(f"Predicted odds movement: {direction} for {sport} {market}")
            return prediction
            
        except Exception as e:
            logger.error(f"Error predicting odds movement: {e}")
            return {"error": str(e)}
    
    def get_daily_predictions(self, sport=None):
        """Get daily predictions summary"""
        try:
            predictions = self.db.get_predictions(sport=sport, limit=50)
            
            if predictions.empty:
                return {"message": "No predictions available yet"}
            
            # Filter today's predictions
            today = datetime.now().date()
            predictions['date'] = pd.to_datetime(predictions['timestamp']).dt.date
            today_predictions = predictions[predictions['date'] == today]
            
            if today_predictions.empty:
                return {"message": "No predictions for today"}
            
            summary = {
                "date": today.isoformat(),
                "total_predictions": len(today_predictions),
                "high_confidence": len(today_predictions[today_predictions['confidence'] >= 0.7]),
                "medium_confidence": len(today_predictions[
                    (today_predictions['confidence'] >= 0.5) & 
                    (today_predictions['confidence'] < 0.7)
                ]),
                "low_confidence": len(today_predictions[today_predictions['confidence'] < 0.5]),
                "sports_covered": today_predictions['sport'].unique().tolist(),
                "avg_confidence": round(today_predictions['confidence'].mean(), 2)
            }
            
            # Top predictions
            top_predictions = today_predictions.nlargest(5, 'confidence')[
                ['sport', 'match_info', 'prediction', 'confidence']
            ].to_dict('records')
            
            summary["top_predictions"] = top_predictions
            
            return summary
            
        except Exception as e:
            logger.error(f"Error getting daily predictions: {e}")
            return {"error": str(e)}
