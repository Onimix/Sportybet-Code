"""
Data analysis utilities for sports betting data
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from utils.database import Database
from utils.logger import get_logger

logger = get_logger("Analyzer")

class BettingAnalyzer:
    def __init__(self):
        self.db = Database()
    
    def analyze_odds_trends(self, sport=None, days=7):
        """Analyze odds trends over time"""
        try:
            # Get data from last N days
            data = self.db.get_betting_data(sport=sport, limit=1000)
            
            if not data:
                return {"error": "No data available for analysis"}
            
            # Convert to DataFrame for analysis
            df = pd.DataFrame(data)
            
            # Convert timestamp to datetime
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            
            # Filter by date range
            cutoff_date = datetime.now() - timedelta(days=days)
            df = df[df['timestamp'] >= cutoff_date]
            
            if df.empty:
                return {"error": f"No data available for the last {days} days"}
            
            analysis = {}
            
            # Overall statistics
            analysis['total_data_points'] = len(df)
            analysis['sports_analyzed'] = df['sport'].unique().tolist()
            analysis['markets_analyzed'] = df['market'].unique().tolist()
            
            # Odds statistics by sport
            odds_by_sport = df.groupby('sport')['odds'].agg([
                'mean', 'median', 'std', 'min', 'max', 'count'
            ]).round(2)
            analysis['odds_by_sport'] = odds_by_sport.to_dict('index')
            
            # Trends by market
            market_trends = df.groupby('market')['odds'].agg([
                'mean', 'std', 'count'
            ]).round(2)
            analysis['market_trends'] = market_trends.to_dict('index')
            
            # Volume analysis
            volume_stats = df.groupby('sport')['volume'].agg([
                'sum', 'mean', 'median', 'max'
            ])
            analysis['volume_by_sport'] = volume_stats.to_dict('index')
            
            # Time-based trends (hourly)
            df['hour'] = df['timestamp'].dt.hour
            hourly_activity = df.groupby('hour').size()
            analysis['hourly_activity'] = hourly_activity.to_dict()
            
            logger.info(f"Completed odds trends analysis for {len(data)} data points")
            return analysis
            
        except Exception as e:
            logger.error(f"Error analyzing odds trends: {e}")
            return {"error": str(e)}
    
    def find_value_bets(self, sport=None, confidence_threshold=0.7):
        """Find potential value bets based on odds analysis"""
        try:
            data = self.db.get_betting_data(sport=sport, limit=500)
            
            if not data or len(data) < 20:
                return {"error": "Insufficient data for value bet analysis"}
            
            # Convert to DataFrame for analysis
            df = pd.DataFrame(data)
            value_bets = []
            
            # Group by sport and market for analysis
            for (sport, market), group in df.groupby(['sport', 'market']):
                if len(group) < 10:  # Need sufficient data
                    continue
                
                # Calculate statistical measures
                mean_odds = group['odds'].mean()
                std_odds = group['odds'].std()
                median_odds = group['odds'].median()
                
                # Find outliers (potential value bets)
                for _, row in group.iterrows():
                    odds = row['odds']
                    z_score = abs((odds - mean_odds) / std_odds) if std_odds > 0 else 0
                    
                    # High odds with low z-score might indicate value
                    if odds > median_odds and z_score < 1.5:
                        confidence = min(0.9, 0.5 + (odds - median_odds) / mean_odds)
                        
                        if confidence >= confidence_threshold:
                            value_bets.append({
                                'sport': sport,
                                'market': market,
                                'team1': row['team1'],
                                'team2': row['team2'],
                                'odds': odds,
                                'confidence': round(confidence, 2),
                                'reason': f"Odds {odds} vs median {median_odds:.2f}",
                                'timestamp': row['timestamp']
                            })
            
            # Sort by confidence
            value_bets.sort(key=lambda x: x['confidence'], reverse=True)
            
            logger.info(f"Found {len(value_bets)} potential value bets")
            return value_bets[:10]  # Return top 10
            
        except Exception as e:
            logger.error(f"Error finding value bets: {e}")
            return {"error": str(e)}
    
    def team_performance_analysis(self, team_name, sport=None):
        """Analyze team performance based on betting data"""
        try:
            data = self.db.get_betting_data(sport=sport, limit=1000)
            
            if not data:
                return {"error": "No data available for analysis"}
            
            # Convert to DataFrame for analysis
            df = pd.DataFrame(data)
            
            # Filter data for the specific team
            team_data = df[
                (df['team1'].str.contains(team_name, case=False, na=False)) |
                (df['team2'].str.contains(team_name, case=False, na=False))
            ]
            
            if team_data.empty:
                return {"error": f"No data found for team: {team_name}"}
            
            analysis = {
                'team_name': team_name,
                'matches_found': len(team_data),
                'sports': team_data['sport'].unique().tolist(),
                'markets': team_data['market'].unique().tolist()
            }
            
            # Odds analysis when team is involved
            analysis['avg_odds'] = round(team_data['odds'].mean(), 2)
            analysis['min_odds'] = round(team_data['odds'].min(), 2)
            analysis['max_odds'] = round(team_data['odds'].max(), 2)
            analysis['odds_std'] = round(team_data['odds'].std(), 2)
            
            # Volume analysis
            analysis['total_volume'] = int(team_data['volume'].sum())
            analysis['avg_volume'] = round(team_data['volume'].mean(), 0)
            
            # Recent performance (last 10 matches)
            recent_matches = team_data.head(10)
            analysis['recent_avg_odds'] = round(recent_matches['odds'].mean(), 2)
            
            logger.info(f"Completed team analysis for {team_name}")
            return analysis
            
        except Exception as e:
            logger.error(f"Error analyzing team performance: {e}")
            return {"error": str(e)}
    
    def market_efficiency_analysis(self, market_type=None):
        """Analyze market efficiency and betting patterns"""
        try:
            data = self.db.get_betting_data(market=market_type, limit=1000)
            
            if not data:
                return {"error": "No data available for market analysis"}
            
            # Convert to DataFrame for analysis
            df = pd.DataFrame(data)
            
            analysis = {}
            
            # Overall market statistics
            analysis['total_events'] = len(df)
            analysis['avg_odds'] = round(df['odds'].mean(), 2)
            analysis['odds_volatility'] = round(df['odds'].std(), 2)
            
            # Market by sport breakdown
            sport_breakdown = df.groupby('sport').agg({
                'odds': ['mean', 'std', 'count'],
                'volume': ['sum', 'mean']
            }).round(2)
            
            analysis['sport_breakdown'] = {}
            for sport in sport_breakdown.index:
                analysis['sport_breakdown'][sport] = {
                    'avg_odds': sport_breakdown.loc[sport, ('odds', 'mean')],
                    'odds_volatility': sport_breakdown.loc[sport, ('odds', 'std')],
                    'event_count': sport_breakdown.loc[sport, ('odds', 'count')],
                    'total_volume': sport_breakdown.loc[sport, ('volume', 'sum')],
                    'avg_volume': sport_breakdown.loc[sport, ('volume', 'mean')]
                }
            
            # Time-based patterns
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            df['day_of_week'] = df['timestamp'].dt.day_name()
            
            daily_patterns = df.groupby('day_of_week').agg({
                'odds': 'mean',
                'volume': 'sum'
            }).round(2)
            analysis['daily_patterns'] = daily_patterns.to_dict('index')
            
            logger.info(f"Completed market efficiency analysis for {len(data)} events")
            return analysis
            
        except Exception as e:
            logger.error(f"Error analyzing market efficiency: {e}")
            return {"error": str(e)}
