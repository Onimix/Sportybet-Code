"""
Configuration settings for the Sports Betting Bot
"""

import os

# Telegram Bot Configuration
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "7961393396:AAHJLjnCZPxvUevYJ_2MPBId2u6Yn6ICTG0")

# Database Configuration
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///sports_betting.db")

# Web Dashboard Configuration
DASHBOARD_HOST = "0.0.0.0"
DASHBOARD_PORT = 5000

# Data Collection Configuration
WEBSOCKET_URL = "wss://alive-ng.on.sportybet2.com/socket.io/?EIO=3&transport=websocket"
COLLECTION_INTERVAL = 10  # seconds

# Prediction Configuration
MIN_DATA_POINTS = 50  # Minimum data points needed for predictions
PREDICTION_CONFIDENCE_THRESHOLD = 0.6

# Sports and Markets Configuration
SUPPORTED_SPORTS = [
    "football", "basketball", "tennis", "cricket", 
    "hockey", "baseball", "volleyball"
]

BETTING_MARKETS = [
    "match_winner", "over_under", "handicap", 
    "both_teams_score", "correct_score"
]

# Mock Data Configuration (for simulation)
MOCK_TEAMS = {
    "football": [
        "Arsenal", "Chelsea", "Liverpool", "Manchester United",
        "Manchester City", "Tottenham", "Barcelona", "Real Madrid",
        "Bayern Munich", "PSG", "Juventus", "AC Milan"
    ],
    "basketball": [
        "Lakers", "Warriors", "Celtics", "Heat", "Bulls", "Knicks",
        "Nets", "76ers", "Bucks", "Raptors", "Clippers", "Nuggets"
    ],
    "tennis": [
        "Novak Djokovic", "Rafael Nadal", "Roger Federer", "Andy Murray",
        "Serena Williams", "Naomi Osaka", "Simona Halep", "Ashleigh Barty"
    ]
}

# Logging Configuration
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
LOG_FILE = "sports_betting_bot.log"
