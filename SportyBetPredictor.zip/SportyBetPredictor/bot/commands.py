"""
Command handlers for the Telegram bot
"""

from telegram import Update
from telegram.ext import ContextTypes
from analysis.predictor import BettingPredictor
from analysis.analyzer import BettingAnalyzer
from utils.database import Database
from utils.logger import get_logger
from config import SUPPORTED_SPORTS

logger = get_logger("BotCommands")

class BotCommands:
    def __init__(self):
        self.predictor = BettingPredictor()
        self.analyzer = BettingAnalyzer()
        self.db = Database()
    
    async def start_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /start command"""
        user_id = update.effective_user.id
        
        welcome_message = """🏆 Welcome to Sports Betting Prediction Bot!

I analyze sports betting data and provide predictions based on statistical analysis.

Available Commands:
/predict <team1> vs <team2> - Get match prediction
/stats - View overall statistics
/trends - Analyze betting trends
/team <team_name> - Analyze team performance
/value - Find potential value bets
/daily - Get daily predictions summary
/analysis <sport> - Sport-specific analysis
/help - Show this help message

Supported Sports:
{}

Example Usage:
/predict Arsenal vs Chelsea
/team Arsenal
/analysis football

Start by trying /stats to see current data!""".format(", ".join(SUPPORTED_SPORTS))
        
        await update.message.reply_text(welcome_message)
        
        # Log interaction
        self.db.log_user_interaction(user_id, "/start", "Welcome message sent")
        logger.info(f"User {user_id} started the bot")
    
    async def help_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /help command"""
        help_message = """🤖 Sports Betting Bot - Help

Commands:

Analysis Commands:
• /stats - Overall statistics and data summary
• /trends - Current betting trends analysis
• /analysis <sport> - Deep dive into specific sport

Prediction Commands:
• /predict <team1> vs <team2> - Match outcome prediction
• /daily - Today's prediction summary
• /value - Find potential value betting opportunities

Team Analysis:
• /team <team_name> - Detailed team performance analysis

Examples:
• /predict Arsenal vs Chelsea
• /team Manchester United
• /analysis football

Need more help? Try /stats to see current data!"""
        
        await update.message.reply_text(help_message)
        
        # Log interaction
        user_id = update.effective_user.id
        self.db.log_user_interaction(user_id, "/help", "Help message sent")
        logger.info(f"User {user_id} requested help")
    
    async def predict_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /predict command"""
        user_id = update.effective_user.id
        
        if not context.args:
            await update.message.reply_text(
                "Please provide teams to predict. Example: /predict Arsenal vs Chelsea"
            )
            return
        
        # Parse team names from arguments
        args_text = " ".join(context.args)
        
        if " vs " not in args_text.lower():
            await update.message.reply_text(
                "Please use format: /predict Team1 vs Team2"
            )
            return
        
        try:
            parts = args_text.lower().split(" vs ")
            team1 = parts[0].strip().title()
            team2 = parts[1].strip().title()
            
            await update.message.reply_text("🔮 Analyzing match data and generating prediction...")
            
            # Get prediction
            prediction = self.predictor.predict_match_outcome("football", team1, team2)
            
            if "error" in prediction:
                await update.message.reply_text(f"⚠️ {prediction['error']}")
                return
            
            # Format prediction message
            confidence_emoji = "🟢" if prediction['confidence'] >= 0.7 else "🟡" if prediction['confidence'] >= 0.5 else "🔴"
            
            message = f"""
🏆 **Match Prediction**

**{prediction['match']}**

{confidence_emoji} **Prediction:** {prediction['predicted_winner']}
📊 **Confidence:** {prediction['confidence'] * 100:.0f}%
💰 **Expected Odds:** {prediction['expected_odds']}

**Analysis:**
• Team 1 avg odds: {prediction['team1_avg_odds']} ({prediction['team1_matches_analyzed']} matches)
• Team 2 avg odds: {prediction['team2_avg_odds']} ({prediction['team2_matches_analyzed']} matches)
• Similar matches found: {prediction['similar_matches_found']}

**Recommendation:** {prediction['recommendation']}
            """
            
            await update.message.reply_text(message, parse_mode='Markdown')
            
            # Log interaction
            self.db.log_user_interaction(user_id, f"/predict {args_text}", "Prediction provided")
            logger.info(f"User {user_id} requested prediction for {team1} vs {team2}")
            
        except Exception as e:
            logger.error(f"Error in predict command: {e}")
            await update.message.reply_text("⚠️ Error generating prediction. Please try again.")
    
    async def stats_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /stats command"""
        user_id = update.effective_user.id
        
        try:
            await update.message.reply_text("📊 Gathering statistics...")
            
            stats = self.db.get_statistics()
            
            if not stats:
                await update.message.reply_text("⚠️ No statistics available yet. Data collection is starting up.")
                return
            
            sports_list = ", ".join(stats.get('sports_covered', [])) or "None yet"
            
            message = f"""
📊 **Bot Statistics**

**Data Collection:**
• Total betting data: {stats.get('total_betting_data', 0):,}
• Recent activity (24h): {stats.get('recent_data_points', 0):,}
• Sports covered: {len(stats.get('sports_covered', []))}

**Predictions:**
• Total predictions made: {stats.get('total_predictions', 0):,}

**Sports:** {sports_list}

Dashboard: http://localhost:5000
            """
            
            await update.message.reply_text(message, parse_mode='Markdown')
            
            # Log interaction
            self.db.log_user_interaction(user_id, "/stats", "Statistics provided")
            logger.info(f"User {user_id} requested statistics")
            
        except Exception as e:
            logger.error(f"Error in stats command: {e}")
            await update.message.reply_text("⚠️ Error retrieving statistics. Please try again.")
    
    async def trends_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /trends command"""
        user_id = update.effective_user.id
        
        try:
            await update.message.reply_text("📈 Analyzing betting trends...")
            
            trends = self.analyzer.analyze_odds_trends()
            
            if "error" in trends:
                await update.message.reply_text(f"⚠️ {trends['error']}")
                return
            
            message = f"""
📈 **Betting Trends Analysis**

**Overview:**
• Data points analyzed: {trends.get('total_data_points', 0):,}
• Sports: {len(trends.get('sports_analyzed', []))}
• Markets: {len(trends.get('markets_analyzed', []))}

**Top Sports by Volume:**
            """
            
            # Add sports volume data if available
            volume_data = trends.get('volume_by_sport', {})
            for sport, data in list(volume_data.items())[:3]:
                if isinstance(data, dict) and 'sum' in data:
                    message += f"• {sport.title()}: {data['sum']:,.0f} volume\n"
            
            message += f"\n**Market Activity:**\n"
            market_data = trends.get('market_trends', {})
            for market, data in list(market_data.items())[:3]:
                if isinstance(data, dict) and 'count' in data:
                    message += f"• {market.replace('_', ' ').title()}: {data['count']} events\n"
            
            await update.message.reply_text(message, parse_mode='Markdown')
            
            # Log interaction
            self.db.log_user_interaction(user_id, "/trends", "Trends analysis provided")
            logger.info(f"User {user_id} requested trends analysis")
            
        except Exception as e:
            logger.error(f"Error in trends command: {e}")
            await update.message.reply_text("⚠️ Error analyzing trends. Please try again.")
    
    async def analysis_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /analysis command"""
        user_id = update.effective_user.id
        sport = context.args[0].lower() if context.args else None
        
        if not sport:
            await update.message.reply_text(
                f"Please specify a sport. Example: `/analysis football`\n\nSupported sports: {', '.join(SUPPORTED_SPORTS)}",
                parse_mode='Markdown'
            )
            return
        
        try:
            await update.message.reply_text(f"🔍 Analyzing {sport} data...")
            
            analysis = self.analyzer.market_efficiency_analysis()
            
            if "error" in analysis:
                await update.message.reply_text(f"⚠️ {analysis['error']}")
                return
            
            message = f"""
🔍 **{sport.title()} Market Analysis**

**Overall Market:**
• Total events: {analysis.get('total_events', 0):,}
• Average odds: {analysis.get('avg_odds', 0):.2f}
• Market volatility: {analysis.get('odds_volatility', 0):.2f}

**Sport Breakdown:**
            """
            
            sport_breakdown = analysis.get('sport_breakdown', {})
            if sport in sport_breakdown:
                data = sport_breakdown[sport]
                message += f"""
• Events analyzed: {data.get('event_count', 0):,}
• Average odds: {data.get('avg_odds', 0):.2f}
• Volatility: {data.get('odds_volatility', 0):.2f}
• Total volume: {data.get('total_volume', 0):,.0f}
                """
            else:
                message += f"\nNo specific data available for {sport} yet."
            
            await update.message.reply_text(message, parse_mode='Markdown')
            
            # Log interaction
            self.db.log_user_interaction(user_id, f"/analysis {sport}", "Analysis provided")
            logger.info(f"User {user_id} requested analysis for {sport}")
            
        except Exception as e:
            logger.error(f"Error in analysis command: {e}")
            await update.message.reply_text("⚠️ Error performing analysis. Please try again.")
    
    async def team_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /team command"""
        user_id = update.effective_user.id
        
        if not context.args:
            await update.message.reply_text(
                "Please specify a team name. Example: `/team Arsenal`",
                parse_mode='Markdown'
            )
            return
        
        team_name = " ".join(context.args)
        
        try:
            await update.message.reply_text(f"🏃 Analyzing {team_name} performance...")
            
            analysis = self.analyzer.team_performance_analysis(team_name)
            
            if "error" in analysis:
                await update.message.reply_text(f"⚠️ {analysis['error']}")
                return
            
            message = f"""
🏃 **{analysis['team_name']} Performance Analysis**

**Overview:**
• Matches analyzed: {analysis.get('matches_found', 0)}
• Sports: {', '.join(analysis.get('sports', []))}
• Markets: {', '.join(analysis.get('markets', []))}

**Betting Odds:**
• Average odds: {analysis.get('avg_odds', 0):.2f}
• Best odds: {analysis.get('min_odds', 0):.2f}
• Worst odds: {analysis.get('max_odds', 0):.2f}
• Volatility: {analysis.get('odds_std', 0):.2f}

**Market Activity:**
• Total volume: {analysis.get('total_volume', 0):,}
• Average volume per match: {analysis.get('avg_volume', 0):,.0f}

**Recent Form:**
• Last 10 matches avg odds: {analysis.get('recent_avg_odds', 0):.2f}
            """
            
            await update.message.reply_text(message, parse_mode='Markdown')
            
            # Log interaction
            self.db.log_user_interaction(user_id, f"/team {team_name}", "Team analysis provided")
            logger.info(f"User {user_id} requested analysis for team {team_name}")
            
        except Exception as e:
            logger.error(f"Error in team command: {e}")
            await update.message.reply_text("⚠️ Error analyzing team. Please try again.")
    
    async def value_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /value command"""
        user_id = update.effective_user.id
        
        try:
            await update.message.reply_text("💰 Finding value betting opportunities...")
            
            value_bets = self.analyzer.find_value_bets()
            
            if isinstance(value_bets, dict) and "error" in value_bets:
                await update.message.reply_text(f"⚠️ {value_bets['error']}")
                return
            
            if not value_bets:
                await update.message.reply_text("📊 No value betting opportunities found at the moment.")
                return
            
            message = "💰 **Value Betting Opportunities**\n\n"
            
            for i, bet in enumerate(value_bets[:5], 1):
                confidence_emoji = "🟢" if bet['confidence'] >= 0.8 else "🟡"
                message += f"""
{confidence_emoji} **{i}. {bet['sport'].title()}**
{bet['team1']} vs {bet['team2']}
• Market: {bet['market'].replace('_', ' ').title()}
• Odds: {bet['odds']} | Confidence: {bet['confidence'] * 100:.0f}%
• {bet['reason']}

"""
            
            await update.message.reply_text(message, parse_mode='Markdown')
            
            # Log interaction
            self.db.log_user_interaction(user_id, "/value", "Value bets provided")
            logger.info(f"User {user_id} requested value bets")
            
        except Exception as e:
            logger.error(f"Error in value command: {e}")
            await update.message.reply_text("⚠️ Error finding value bets. Please try again.")
    
    async def daily_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /daily command"""
        user_id = update.effective_user.id
        
        try:
            await update.message.reply_text("📅 Generating daily predictions summary...")
            
            summary = self.predictor.get_daily_predictions()
            
            if "error" in summary:
                await update.message.reply_text(f"⚠️ {summary['error']}")
                return
            
            if "message" in summary:
                await update.message.reply_text(f"📅 {summary['message']}")
                return
            
            message = f"""
📅 **Daily Predictions Summary**

**Today's Stats:**
• Total predictions: {summary.get('total_predictions', 0)}
• High confidence (70%+): {summary.get('high_confidence', 0)}
• Medium confidence (50-70%): {summary.get('medium_confidence', 0)}
• Low confidence (<50%): {summary.get('low_confidence', 0)}

**Average confidence:** {summary.get('avg_confidence', 0) * 100:.0f}%
**Sports covered:** {', '.join(summary.get('sports_covered', []))}

**Top Predictions:**
            """
            
            top_predictions = summary.get('top_predictions', [])
            for i, pred in enumerate(top_predictions[:3], 1):
                confidence_emoji = "🟢" if pred['confidence'] >= 0.7 else "🟡"
                message += f"""
{confidence_emoji} {i}. {pred['sport'].title()}: {pred['match_info']}
   Prediction: {pred['prediction']} ({pred['confidence'] * 100:.0f}%)

"""
            
            await update.message.reply_text(message, parse_mode='Markdown')
            
            # Log interaction
            self.db.log_user_interaction(user_id, "/daily", "Daily summary provided")
            logger.info(f"User {user_id} requested daily summary")
            
        except Exception as e:
            logger.error(f"Error in daily command: {e}")
            await update.message.reply_text("⚠️ Error generating daily summary. Please try again.")
    
    async def handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle text messages"""
        user_id = update.effective_user.id
        message_text = update.message.text.lower()
        
        # Simple keyword-based responses
        if any(word in message_text for word in ['predict', 'prediction']):
            await update.message.reply_text(
                "🔮 Use `/predict Team1 vs Team2` to get match predictions!\n\nExample: `/predict Arsenal vs Chelsea`",
                parse_mode='Markdown'
            )
        elif any(word in message_text for word in ['stats', 'statistics']):
            await update.message.reply_text("📊 Use `/stats` to see current statistics!")
        elif any(word in message_text for word in ['help', 'commands']):
            await update.message.reply_text("🤖 Use `/help` to see all available commands!")
        elif any(word in message_text for word in ['trend', 'trends']):
            await update.message.reply_text("📈 Use `/trends` to see current betting trends!")
        else:
            await update.message.reply_text(
                "👋 Hello! I'm your Sports Betting Bot. Use `/help` to see what I can do!",
                parse_mode='Markdown'
            )
        
        # Log interaction
        self.db.log_user_interaction(user_id, f"message: {message_text[:50]}...", "General response")
        logger.info(f"User {user_id} sent message: {message_text[:50]}...")
