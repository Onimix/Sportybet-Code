"""
Telegram bot implementation for sports betting predictions
"""

import asyncio
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes
from bot.commands import BotCommands
from utils.logger import get_logger
from config import TELEGRAM_BOT_TOKEN

logger = get_logger("TelegramBot")

class SportsBettingBot:
    def __init__(self):
        self.token = TELEGRAM_BOT_TOKEN
        self.commands = BotCommands()
        self.application = None
    
    async def start_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /start command"""
        await self.commands.start_command(update, context)
    
    async def help_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /help command"""
        await self.commands.help_command(update, context)
    
    async def predict_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /predict command"""
        await self.commands.predict_command(update, context)
    
    async def stats_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /stats command"""
        await self.commands.stats_command(update, context)
    
    async def trends_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /trends command"""
        await self.commands.trends_command(update, context)
    
    async def analysis_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /analysis command"""
        await self.commands.analysis_command(update, context)
    
    async def team_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /team command"""
        await self.commands.team_command(update, context)
    
    async def value_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /value command"""
        await self.commands.value_command(update, context)
    
    async def daily_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /daily command"""
        await self.commands.daily_command(update, context)
    
    async def message_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle text messages"""
        await self.commands.handle_message(update, context)
    
    async def error_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle errors"""
        logger.error(f"Update {update} caused error {context.error}")
        
        if update and update.effective_chat:
            await context.bot.send_message(
                chat_id=update.effective_chat.id,
                text="⚠️ An error occurred while processing your request. Please try again later."
            )
    
    def setup_handlers(self):
        """Setup command and message handlers"""
        # Command handlers
        self.application.add_handler(CommandHandler("start", self.start_handler))
        self.application.add_handler(CommandHandler("help", self.help_handler))
        self.application.add_handler(CommandHandler("predict", self.predict_handler))
        self.application.add_handler(CommandHandler("stats", self.stats_handler))
        self.application.add_handler(CommandHandler("trends", self.trends_handler))
        self.application.add_handler(CommandHandler("analysis", self.analysis_handler))
        self.application.add_handler(CommandHandler("team", self.team_handler))
        self.application.add_handler(CommandHandler("value", self.value_handler))
        self.application.add_handler(CommandHandler("daily", self.daily_handler))
        
        # Message handler
        self.application.add_handler(
            MessageHandler(filters.TEXT & ~filters.COMMAND, self.message_handler)
        )
        
        # Error handler
        self.application.add_error_handler(self.error_handler)
        
        logger.info("Bot handlers setup complete")
    
    def run(self):
        """Run the bot"""
        try:
            if not self.token or self.token == "YOUR_BOT_TOKEN_HERE":
                logger.error("Telegram bot token not provided. Please set TELEGRAM_BOT_TOKEN environment variable.")
                print("\n⚠️  Telegram Bot Token Required!")
                print("Please set the TELEGRAM_BOT_TOKEN environment variable with your bot token.")
                print("You can get a bot token from @BotFather on Telegram.")
                print("\nExample:")
                print("export TELEGRAM_BOT_TOKEN='your_token_here'")
                print("python main.py")
                return
            
            # Create application
            self.application = Application.builder().token(self.token).build()
            
            # Setup handlers
            self.setup_handlers()
            
            logger.info("Starting Telegram bot...")
            print("🤖 Sports Betting Bot is starting...")
            print(f"📊 Dashboard available at: http://localhost:5000")
            
            # Run the bot
            self.application.run_polling(allowed_updates=Update.ALL_TYPES)
            
        except Exception as e:
            logger.error(f"Error running bot: {e}")
            raise
